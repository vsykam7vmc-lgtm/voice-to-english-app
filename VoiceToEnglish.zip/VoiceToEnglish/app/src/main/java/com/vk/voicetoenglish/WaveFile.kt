package com.vk.voicetoenglish

import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

object WaveFile {

    /** Decodes a 16-bit PCM WAV file into normalized floats in [-1, 1], as whisper.cpp expects. */
    fun decodeToFloats(file: File): FloatArray {
        val baos = ByteArrayOutputStream()
        file.inputStream().use { it.copyTo(baos) }
        val buffer = ByteBuffer.wrap(baos.toByteArray())
        buffer.order(ByteOrder.LITTLE_ENDIAN)
        val channels = buffer.getShort(22).toInt()
        buffer.position(44)
        val shortBuffer = buffer.asShortBuffer()
        val shortArray = ShortArray(shortBuffer.limit())
        shortBuffer.get(shortArray)
        return FloatArray(shortArray.size / channels) { index ->
            when (channels) {
                1 -> (shortArray[index] / 32767.0f).coerceIn(-1f..1f)
                else -> ((shortArray[2 * index] + shortArray[2 * index + 1]) / 32767.0f / 2.0f).coerceIn(-1f..1f)
            }
        }
    }

    /** Writes 16-bit mono PCM samples to a standard RIFF/WAVE file at [sampleRate] Hz. */
    fun encode(file: File, data: ShortArray, sampleRate: Int) {
        file.outputStream().use { out ->
            out.write(header(dataLengthBytes = data.size * 2, sampleRate = sampleRate))
            val buffer = ByteBuffer.allocate(data.size * 2)
            buffer.order(ByteOrder.LITTLE_ENDIAN)
            buffer.asShortBuffer().put(data)
            out.write(buffer.array())
        }
    }

    private fun header(dataLengthBytes: Int, sampleRate: Int): ByteArray {
        val totalLength = dataLengthBytes + 44
        val byteRate = sampleRate * 2 // mono, 16-bit
        return ByteBuffer.allocate(44).apply {
            order(ByteOrder.LITTLE_ENDIAN)
            put('R'.code.toByte()); put('I'.code.toByte()); put('F'.code.toByte()); put('F'.code.toByte())
            putInt(totalLength - 8)
            put('W'.code.toByte()); put('A'.code.toByte()); put('V'.code.toByte()); put('E'.code.toByte())
            put('f'.code.toByte()); put('m'.code.toByte()); put('t'.code.toByte()); put(' '.code.toByte())
            putInt(16)
            putShort(1.toShort())        // PCM
            putShort(1.toShort())        // mono
            putInt(sampleRate)
            putInt(byteRate)
            putShort(2.toShort())        // block align
            putShort(16.toShort())       // bits per sample
            put('d'.code.toByte()); put('a'.code.toByte()); put('t'.code.toByte()); put('a'.code.toByte())
            putInt(dataLengthBytes)
            position(0)
        }.let {
            val bytes = ByteArray(44)
            it.get(bytes)
            bytes
        }
    }
}
