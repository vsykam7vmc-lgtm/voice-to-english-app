package com.vk.voicetoenglish.ui.theme

import androidx.compose.ui.graphics.Color

val Navy80 = Color(0xFFB8C7DA)
val Teal80 = Color(0xFFB6E3D4)

val Navy40 = Color(0xFF1A3A5C)
val Teal40 = Color(0xFF1E7A5C)

val Background = Color(0xFFF7F8FA)
val SurfaceCard = Color(0xFFFFFFFF)
