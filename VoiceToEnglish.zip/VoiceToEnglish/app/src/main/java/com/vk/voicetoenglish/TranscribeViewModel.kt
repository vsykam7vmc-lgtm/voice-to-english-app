package com.vk.voicetoenglish

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.vk.whisper.WhisperContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.io.File

data class Language(val code: String, val label: String)

val SUPPORTED_LANGUAGES = listOf(
    Language("auto", "Auto-detect"),
    Language("te", "Telugu"),
    Language("hi", "Hindi"),
    Language("ta", "Tamil"),
    Language("kn", "Kannada"),
    Language("ml", "Malayalam"),
    Language("mr", "Marathi"),
    Language("bn", "Bengali"),
    Language("gu", "Gujarati"),
    Language("ur", "Urdu"),
    Language("en", "English")
)

enum class Stage { NO_MODEL, LOADING_MODEL, READY, RECORDING, PROCESSING }

data class UiState(
    val stage: Stage = Stage.NO_MODEL,
    val selectedLanguage: Language = SUPPORTED_LANGUAGES[1], // Telugu by default
    val originalText: String = "",
    val englishText: String = "",
    val detectedLanguage: String? = null,
    val modelFileName: String? = null,
    val error: String? = null
)

class TranscribeViewModel(app: Application) : AndroidViewModel(app) {

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state

    private var whisper: WhisperContext? = null
    private val recorder = AudioRecorder()
    private val recordingFile: File
        get() = File(getApplication<Application>().cacheDir, "recording.wav")

    private fun modelFile() = File(getApplication<Application>().filesDir, "models/model.bin")

    init {
        val existing = modelFile()
        if (existing.exists()) {
            loadModelFromFile(existing)
        }
    }

    fun selectLanguage(language: Language) {
        _state.value = _state.value.copy(selectedLanguage = language)
    }

    /** Called after the user picks a .bin ggml model file via the system file picker. */
    fun importModel(uri: Uri) {
        val app = getApplication<Application>()
        _state.value = _state.value.copy(stage = Stage.LOADING_MODEL, error = null)
        viewModelScope.launch {
            try {
                val dest = modelFile()
                dest.parentFile?.mkdirs()
                app.contentResolver.openInputStream(uri)?.use { input ->
                    dest.outputStream().use { output -> input.copyTo(output) }
                } ?: throw IllegalStateException("Could not open the selected file")
                loadModelFromFile(dest)
            } catch (e: Exception) {
                _state.value = _state.value.copy(stage = Stage.NO_MODEL, error = "Couldn't import model: ${e.message}")
            }
        }
    }

    private fun loadModelFromFile(file: File) {
        viewModelScope.launch {
            try {
                whisper?.release()
                whisper = WhisperContext.createContextFromFile(file.absolutePath)
                _state.value = _state.value.copy(
                    stage = Stage.READY,
                    modelFileName = file.name + "  (" + sizeLabel(file.length()) + ")",
                    error = null
                )
            } catch (e: Exception) {
                _state.value = _state.value.copy(stage = Stage.NO_MODEL, error = "Couldn't load model: ${e.message}")
            }
        }
    }

    private fun sizeLabel(bytes: Long): String {
        val mb = bytes / (1024.0 * 1024.0)
        return "%.0f MB".format(mb)
    }

    fun startRecording() {
        if (_state.value.stage != Stage.READY) return
        _state.value = _state.value.copy(
            stage = Stage.RECORDING,
            originalText = "",
            englishText = "",
            detectedLanguage = null,
            error = null
        )
        viewModelScope.launch {
            recorder.start(recordingFile) { e ->
                _state.value = _state.value.copy(stage = Stage.READY, error = "Recording error: ${e.message}")
            }
        }
    }

    fun stopRecordingAndProcess() {
        if (_state.value.stage != Stage.RECORDING) return
        _state.value = _state.value.copy(stage = Stage.PROCESSING)
        viewModelScope.launch {
            recorder.stop()
            val ctx = whisper
            if (ctx == null) {
                _state.value = _state.value.copy(stage = Stage.NO_MODEL, error = "Model not loaded")
                return@launch
            }
            try {
                val floats = WaveFile.decodeToFloats(recordingFile)
                val langCode = _state.value.selectedLanguage.code
                val result = ctx.transcribeAndTranslate(floats, langCode)
                _state.value = _state.value.copy(
                    stage = Stage.READY,
                    originalText = result.originalText,
                    englishText = result.englishText,
                    detectedLanguage = result.detectedLanguage
                )
            } catch (e: Exception) {
                _state.value = _state.value.copy(stage = Stage.READY, error = "Transcription failed: ${e.message}")
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        viewModelScope.launch { whisper?.release() }
    }
}
