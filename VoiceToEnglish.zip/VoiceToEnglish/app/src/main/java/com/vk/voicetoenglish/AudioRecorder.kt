package com.vk.voicetoenglish

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

private const val SAMPLE_RATE = 16000 // whisper.cpp requires 16kHz mono PCM16 input

class AudioRecorder {
    private val scope: CoroutineScope = CoroutineScope(
        Executors.newSingleThreadExecutor().asCoroutineDispatcher()
    )
    private var recordThread: RecordThread? = null

    suspend fun start(outputFile: File, onError: (Exception) -> Unit) = withContext(scope.coroutineContext) {
        recordThread = RecordThread(outputFile, onError)
        recordThread?.start()
    }

    suspend fun stop() = withContext(scope.coroutineContext) {
        recordThread?.requestStop()
        @Suppress("BlockingMethodInNonBlockingContext")
        recordThread?.join()
        recordThread = null
    }
}

private class RecordThread(
    private val outputFile: File,
    private val onError: (Exception) -> Unit
) : Thread("AudioRecorder") {
    private val quit = AtomicBoolean(false)

    @SuppressLint("MissingPermission")
    override fun run() {
        try {
            val minBuffer = AudioRecord.getMinBufferSize(
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            val bufferSize = minBuffer * 4
            val buffer = ShortArray(bufferSize / 2)

            val audioRecord = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferSize
            )

            try {
                audioRecord.startRecording()
                val allSamples = mutableListOf<Short>()

                while (!quit.get()) {
                    val read = audioRecord.read(buffer, 0, buffer.size)
                    if (read > 0) {
                        for (i in 0 until read) allSamples.add(buffer[i])
                    } else if (read < 0) {
                        throw RuntimeException("AudioRecord.read() returned error code $read")
                    }
                }

                audioRecord.stop()
                WaveFile.encode(outputFile, allSamples.toShortArray(), SAMPLE_RATE)
            } finally {
                audioRecord.release()
            }
        } catch (e: Exception) {
            onError(e)
        }
    }

    fun requestStop() {
        quit.set(true)
    }
}
