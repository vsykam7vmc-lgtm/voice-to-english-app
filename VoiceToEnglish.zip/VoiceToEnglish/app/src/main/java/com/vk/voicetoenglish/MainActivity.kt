package com.vk.voicetoenglish

import android.Manifest
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.vk.voicetoenglish.ui.theme.VoiceToEnglishTheme
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import com.google.accompanist.permissions.shouldShowRationale

class MainActivity : ComponentActivity() {
    private val viewModel: TranscribeViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            VoiceToEnglishTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AppScreen(viewModel)
                }
            }
        }
    }
}

@OptIn(ExperimentalPermissionsApi::class, ExperimentalMaterial3Api::class)
@Composable
fun AppScreen(viewModel: TranscribeViewModel) {
    val state by viewModel.state.collectAsState()
    val context = LocalContext.current
    val micPermission = rememberPermissionState(Manifest.permission.RECORD_AUDIO)

    val modelPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { viewModel.importModel(it) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Voice to English") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            // ---- Model status / import ----
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Offline model", style = MaterialTheme.typography.labelLarge)
                    Spacer(Modifier.height(4.dp))
                    when (state.stage) {
                        Stage.NO_MODEL -> {
                            Text(
                                "No model loaded yet. Download a ggml Whisper model " +
                                    "(e.g. ggml-small.bin) and import it below.",
                                style = MaterialTheme.typography.bodyLarge
                            )
                            Spacer(Modifier.height(8.dp))
                            Button(onClick = { modelPicker.launch(arrayOf("*/*")) }) {
                                Icon(Icons.Filled.UploadFile, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text("Import model file (.bin)")
                            }
                        }
                        Stage.LOADING_MODEL -> {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                                Spacer(Modifier.width(8.dp))
                                Text("Loading model\u2026")
                            }
                        }
                        else -> {
                            Text(state.modelFileName ?: "Model loaded", style = MaterialTheme.typography.bodyLarge)
                            TextButton(onClick = { modelPicker.launch(arrayOf("*/*")) }) {
                                Text("Change model")
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            // ---- Language picker ----
            LanguageDropdown(
                selected = state.selectedLanguage,
                enabled = state.stage == Stage.READY,
                onSelect = { viewModel.selectLanguage(it) }
            )

            Spacer(Modifier.height(24.dp))

            // ---- Record button ----
            val canUseModel = state.stage == Stage.READY || state.stage == Stage.RECORDING || state.stage == Stage.PROCESSING
            if (!micPermission.status.isGranted) {
                Button(onClick = { micPermission.launchPermissionRequest() }) {
                    Text(if (micPermission.status.shouldShowRationale) "Allow microphone access" else "Grant microphone permission")
                }
            } else {
                RecordButton(
                    stage = state.stage,
                    enabled = canUseModel,
                    onStart = { viewModel.startRecording() },
                    onStop = { viewModel.stopRecordingAndProcess() }
                )
            }

            Spacer(Modifier.height(8.dp))
            Text(
                when (state.stage) {
                    Stage.RECORDING -> "Recording\u2026 tap to stop"
                    Stage.PROCESSING -> "Transcribing and translating\u2026"
                    Stage.READY -> "Tap to record"
                    else -> ""
                },
                style = MaterialTheme.typography.bodyLarge
            )

            state.error?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, color = MaterialTheme.colorScheme.error)
            }

            Spacer(Modifier.height(24.dp))

            if (state.originalText.isNotBlank() || state.englishText.isNotBlank()) {
                val originalLabel = if (state.selectedLanguage.code == "auto" && state.detectedLanguage != null) {
                    "Original (detected: ${state.detectedLanguage})"
                } else {
                    "Original (${state.selectedLanguage.label})"
                }
                ResultCard(title = originalLabel, text = state.originalText)
                Spacer(Modifier.height(12.dp))
                ResultCard(title = "English translation", text = state.englishText)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LanguageDropdown(selected: Language, enabled: Boolean, onSelect: (Language) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { if (enabled) expanded = it },
        modifier = Modifier.fillMaxWidth()
    ) {
        OutlinedTextField(
            value = selected.label,
            onValueChange = {},
            readOnly = true,
            enabled = enabled,
            label = { Text("Spoken language") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier.fillMaxWidth().menuAnchor()
        )
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            SUPPORTED_LANGUAGES.forEach { lang ->
                DropdownMenuItem(
                    text = { Text(lang.label) },
                    onClick = {
                        onSelect(lang)
                        expanded = false
                    }
                )
            }
        }
    }
}

@Composable
fun RecordButton(stage: Stage, enabled: Boolean, onStart: () -> Unit, onStop: () -> Unit) {
    val isRecording = stage == Stage.RECORDING
    val isProcessing = stage == Stage.PROCESSING
    Box(
        modifier = Modifier.size(96.dp),
        contentAlignment = Alignment.Center
    ) {
        if (isProcessing) {
            CircularProgressIndicator(modifier = Modifier.size(96.dp), strokeWidth = 4.dp)
        }
        FilledIconButton(
            onClick = { if (isRecording) onStop() else onStart() },
            enabled = enabled && !isProcessing,
            shape = CircleShape,
            modifier = Modifier.size(80.dp),
            colors = IconButtonDefaults.filledIconButtonColors(
                containerColor = if (isRecording) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
            )
        ) {
            Icon(
                imageVector = if (isRecording) Icons.Filled.Stop else Icons.Filled.Mic,
                contentDescription = if (isRecording) "Stop recording" else "Start recording",
                modifier = Modifier.size(36.dp)
            )
        }
    }
}

@Composable
fun ResultCard(title: String, text: String) {
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(title, fontWeight = FontWeight.SemiBold)
                Row {
                    IconButton(onClick = { clipboard.setText(AnnotatedString(text)) }) {
                        Icon(Icons.Filled.ContentCopy, contentDescription = "Copy")
                    }
                    IconButton(onClick = {
                        val intent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, text)
                        }
                        context.startActivity(Intent.createChooser(intent, title))
                    }) {
                        Icon(Icons.Filled.Share, contentDescription = "Share")
                    }
                }
            }
            Spacer(Modifier.height(4.dp))
            Text(
                text.ifBlank { "\u2014" },
                style = MaterialTheme.typography.bodyLarge
            )
        }
    }
}
