package com.vk.whisper

import android.os.Build
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors

private const val LOG_TAG = "LibWhisper"

/** Result of running both an original-language transcription and an English translation pass. */
data class WhisperResult(
    val originalText: String,
    val englishText: String,
    val detectedLanguage: String?
)

class WhisperContext private constructor(private var ptr: Long) {
    // whisper.cpp contexts are not thread-safe: always touch them from one dedicated thread.
    private val scope: CoroutineScope = CoroutineScope(
        Executors.newSingleThreadExecutor().asCoroutineDispatcher()
    )

    /**
     * Runs whisper twice over the same audio:
     *   1) plain transcription in [languageCode] (or auto-detected)
     *   2) translation of the same audio directly into English
     *
     * [languageCode] should be an ISO-639-1 code such as "te", "hi", "en", or "auto".
     */
    suspend fun transcribeAndTranslate(data: FloatArray, languageCode: String): WhisperResult =
        withContext(scope.coroutineContext) {
            require(ptr != 0L)
            val numThreads = WhisperCpuConfig.preferredThreadCount
            Log.d(LOG_TAG, "Using $numThreads threads")

            // Pass 1: transcript in the original spoken language.
            WhisperLib.fullTranscribe(ptr, numThreads, data, languageCode, false)
            val original = collectSegments()
            val detected = if (languageCode == "auto") WhisperLib.getDetectedLanguage(ptr) else null

            // Pass 2: direct translation into English.
            WhisperLib.fullTranscribe(ptr, numThreads, data, languageCode, true)
            val english = collectSegments()

            WhisperResult(original, english, detected)
        }

    private fun collectSegments(): String {
        val count = WhisperLib.getTextSegmentCount(ptr)
        return buildString {
            for (i in 0 until count) {
                append(WhisperLib.getTextSegment(ptr, i))
            }
        }.trim()
    }

    suspend fun release() = withContext(scope.coroutineContext) {
        if (ptr != 0L) {
            WhisperLib.freeContext(ptr)
            ptr = 0
        }
    }

    protected fun finalize() {
        if (ptr != 0L) {
            WhisperLib.freeContext(ptr)
            ptr = 0
        }
    }

    companion object {
        fun createContextFromFile(filePath: String): WhisperContext {
            val ptr = WhisperLib.initContext(filePath)
            if (ptr == 0L) {
                throw RuntimeException("Couldn't load whisper model from $filePath")
            }
            return WhisperContext(ptr)
        }

        fun getSystemInfo(): String = WhisperLib.getSystemInfo()
    }
}

private class WhisperLib {
    companion object {
        init {
            Log.d(LOG_TAG, "Primary ABI: ${Build.SUPPORTED_ABIS[0]}")
            var loadVfpv4 = false
            var loadV8fp16 = false
            if (isArmEabiV7a()) {
                val cpuInfo = cpuInfo()
                cpuInfo?.let {
                    if (it.contains("vfpv4")) loadVfpv4 = true
                }
            } else if (isArmEabiV8a()) {
                val cpuInfo = cpuInfo()
                cpuInfo?.let {
                    if (it.contains("fphp")) loadV8fp16 = true
                }
            }

            when {
                loadVfpv4 -> {
                    Log.d(LOG_TAG, "Loading libwhisper_vfpv4.so")
                    System.loadLibrary("whisper_vfpv4")
                }
                loadV8fp16 -> {
                    Log.d(LOG_TAG, "Loading libwhisper_v8fp16_va.so")
                    System.loadLibrary("whisper_v8fp16_va")
                }
                else -> {
                    Log.d(LOG_TAG, "Loading libwhisper.so")
                    System.loadLibrary("whisper")
                }
            }
        }

        // JNI methods - implemented in lib/src/main/jni/whisper/jni.c
        external fun initContext(modelPath: String): Long
        external fun freeContext(contextPtr: Long)
        external fun fullTranscribe(
            contextPtr: Long,
            numThreads: Int,
            audioData: FloatArray,
            language: String,
            translate: Boolean
        )
        external fun getTextSegmentCount(contextPtr: Long): Int
        external fun getTextSegment(contextPtr: Long, index: Int): String
        external fun getDetectedLanguage(contextPtr: Long): String
        external fun getSystemInfo(): String
    }
}

private fun isArmEabiV7a(): Boolean = Build.SUPPORTED_ABIS[0] == "armeabi-v7a"
private fun isArmEabiV8a(): Boolean = Build.SUPPORTED_ABIS[0] == "arm64-v8a"

private fun cpuInfo(): String? = try {
    java.io.File("/proc/cpuinfo").inputStream().bufferedReader().use { it.readText() }
} catch (e: Exception) {
    Log.w(LOG_TAG, "Couldn't read /proc/cpuinfo", e)
    null
}
